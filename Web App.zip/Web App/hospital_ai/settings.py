# hospital_ai/settings.py

from pathlib import Path
import os

from dotenv import load_dotenv

BASE_DIR = Path(__file__).resolve().parent.parent

# Load local .env if present (safe in GitHub Actions / Render too)
load_dotenv(BASE_DIR / ".env")

# -----------------------------------------------------------------------------
# Core settings
# -----------------------------------------------------------------------------
SECRET_KEY = os.getenv("DJANGO_SECRET_KEY", "dev-only-change-me")
DEBUG = os.getenv("DJANGO_DEBUG", "1") == "1"

# If you want to control this via env, set:
# DJANGO_ALLOWED_HOSTS=127.0.0.1,localhost,.onrender.com,mortalityapp.onrender.com
_allowed = os.getenv(
    "DJANGO_ALLOWED_HOSTS",
    "127.0.0.1,localhost,.onrender.com,mortalityapp.onrender.com",
)
ALLOWED_HOSTS = [h.strip() for h in _allowed.split(",") if h.strip()]

# If you use Render custom domain / HTTPS reverse proxy, these help:
SECURE_PROXY_SSL_HEADER = ("HTTP_X_FORWARDED_PROTO", "https")

# If you ever hit CSRF issues on Render, uncomment and set:
# CSRF_TRUSTED_ORIGINS = [
#     "https://*.onrender.com",
#     "https://mortalityapp.onrender.com",
# ]

# -----------------------------------------------------------------------------
# Apps
# -----------------------------------------------------------------------------
INSTALLED_APPS = [
    "django.contrib.admin",
    "django.contrib.auth",
    "django.contrib.contenttypes",
    "django.contrib.sessions",
    "django.contrib.messages",
    "django.contrib.staticfiles",
    # local apps
    "accounts",
    "patients",
    "observations",
    "risk",
    "audit",
]

MIDDLEWARE = [
    "django.middleware.security.SecurityMiddleware",
    "whitenoise.middleware.WhiteNoiseMiddleware",
    "django.contrib.sessions.middleware.SessionMiddleware",
    "django.middleware.common.CommonMiddleware",
    "django.middleware.csrf.CsrfViewMiddleware",
    "django.contrib.auth.middleware.AuthenticationMiddleware",
    "django.contrib.messages.middleware.MessageMiddleware",
    "django.middleware.clickjacking.XFrameOptionsMiddleware",
]

ROOT_URLCONF = "hospital_ai.urls"

TEMPLATES = [
    {
        "BACKEND": "django.template.backends.django.DjangoTemplates",
        "DIRS": [BASE_DIR / "templates"],
        "APP_DIRS": True,
        "OPTIONS": {
            "context_processors": [
                "django.template.context_processors.debug",
                "django.template.context_processors.request",
                "django.contrib.auth.context_processors.auth",
                "django.contrib.messages.context_processors.messages",
            ],
        },
    },
]

WSGI_APPLICATION = "hospital_ai.wsgi.application"

# -----------------------------------------------------------------------------
# Database (supports BOTH DATABASE_URL and DB_*)
# -----------------------------------------------------------------------------
DATABASE_URL = (os.getenv("DATABASE_URL") or "").strip()

if DATABASE_URL:
    # Preferred for many hosts (Render, Heroku-like, etc.)
    try:
        import dj_database_url  # pip install dj-database-url
    except Exception as e:
        raise RuntimeError(
            "DATABASE_URL is set but dj-database-url is not installed. "
            "Run: pip install dj-database-url"
        ) from e

    DATABASES = {
        "default": dj_database_url.parse(
            DATABASE_URL,
            conn_max_age=600,
            ssl_require=True,  # Supabase requires SSL
        )
    }
else:
    # Fallback: classic DB_* variables (your current style)
    DATABASES = {
        "default": {
            "ENGINE": os.getenv("DB_ENGINE", "django.db.backends.postgresql"),
            "NAME": os.getenv("DB_NAME", "postgres"),
            "USER": os.getenv("DB_USER", ""),
            "PASSWORD": os.getenv("DB_PASSWORD", ""),
            "HOST": os.getenv("DB_HOST", "localhost"),
            "PORT": os.getenv("DB_PORT", "5432"),
            "OPTIONS": {"sslmode": "require"},  # Supabase
        }
    }

# -----------------------------------------------------------------------------
# Auth / i18n
# -----------------------------------------------------------------------------
AUTH_PASSWORD_VALIDATORS = [
    {"NAME": "django.contrib.auth.password_validation.UserAttributeSimilarityValidator"},
    {"NAME": "django.contrib.auth.password_validation.MinimumLengthValidator"},
    {"NAME": "django.contrib.auth.password_validation.CommonPasswordValidator"},
    {"NAME": "django.contrib.auth.password_validation.NumericPasswordValidator"},
]

LANGUAGE_CODE = "en-us"
TIME_ZONE = os.getenv("DJANGO_TIME_ZONE", "Europe/Berlin")
USE_I18N = True
USE_TZ = True

DEFAULT_AUTO_FIELD = "django.db.models.BigAutoField"

LOGIN_URL = "accounts:login"
LOGIN_REDIRECT_URL = "patients:patient_list"
LOGOUT_REDIRECT_URL = "accounts:login"

# -----------------------------------------------------------------------------
# Static files
# -----------------------------------------------------------------------------
STATIC_URL = "/static/"
STATICFILES_DIRS = [BASE_DIR / "static"]
STATIC_ROOT = BASE_DIR / "staticfiles"
STATICFILES_STORAGE = "whitenoise.storage.CompressedManifestStaticFilesStorage"

# -----------------------------------------------------------------------------
# ML models (3 models, same feature set)
# -----------------------------------------------------------------------------
# Env overrides supported:
#   DEFAULT_ML_MODEL_KEY (mort_180 / mort_90 / mort_in)
#   ML_MODEL_180_PATH, ML_MODEL_180_VERSION
#   ML_MODEL_90_PATH,  ML_MODEL_90_VERSION
#   ML_MODEL_IN_PATH,  ML_MODEL_IN_VERSION
#
# IMPORTANT: Put your .joblib files into risk/ml_models/ OR set the env paths.

DEFAULT_ML_MODEL_KEY = os.getenv("DEFAULT_ML_MODEL_KEY", "mort_180")

ML_MODELS = {
    "mort_180": {
        "label": "180-day mortality",
        "path": os.getenv(
            "ML_MODEL_180_PATH",
            str(BASE_DIR / "risk" / "ml_models" / "XGBoost_mortality_180days.joblib"),
        ),
        "version": os.getenv("ML_MODEL_180_VERSION", "2025-12-31-xgb-180d"),
    },
    "mort_90": {
        "label": "90-day mortality",
        "path": os.getenv(
            "ML_MODEL_90_PATH",
            str(BASE_DIR / "risk" / "ml_models" / "XGBoost_mortality_90days.joblib"),
        ),
        "version": os.getenv("ML_MODEL_90_VERSION", "2025-12-31-xgb-90d"),
    },
    "mort_in": {
        "label": "In-hospital mortality",
        "path": os.getenv(
            "ML_MODEL_IN_PATH",
            str(BASE_DIR / "risk" / "ml_models" / "XGBoost_mortality_inhospital.joblib"),
        ),
        "version": os.getenv("ML_MODEL_IN_VERSION", "2025-12-31-xgb-inhosp"),
    },
}

# Backwards compatibility (so older code that uses ML_MODEL_PATH still works)
ML_MODEL_PATH = ML_MODELS[DEFAULT_ML_MODEL_KEY]["path"]
ML_MODEL_VERSION = ML_MODELS[DEFAULT_ML_MODEL_KEY]["version"]

# Risk bands (edit to match hospital policy)
RISK_BAND_THRESHOLDS = {
    "LOW": 0.30,
    "MEDIUM": 0.70,
    # >= MEDIUM threshold becomes HIGH
}

# -----------------------------------------------------------------------------
# Raw-measurements ingestion
# -----------------------------------------------------------------------------
# Supabase Storage (public bucket preferred for simple setup)
SUPABASE_URL = os.getenv("SUPABASE_URL", "")
# For private buckets you will need this; for public it can stay empty.
SUPABASE_SERVICE_ROLE_KEY = os.getenv("SUPABASE_SERVICE_ROLE_KEY", "")
SUPABASE_BUCKET_NAME = os.getenv("SUPABASE_BUCKET_NAME", "")
SUPABASE_OBJECT_KEY_TEMPLATE = os.getenv(
    "SUPABASE_OBJECT_KEY_TEMPLATE", "patients/{mrn}/encounters/{encounter_id}.json"
)
SUPABASE_TIMEOUT = int(os.getenv("SUPABASE_TIMEOUT", "15"))

# Cloudflare R2 (optional)
R2_ACCOUNT_ID = os.getenv("R2_ACCOUNT_ID", "")
R2_ACCESS_KEY_ID = os.getenv("R2_ACCESS_KEY_ID", "")
R2_SECRET_ACCESS_KEY = os.getenv("R2_SECRET_ACCESS_KEY", "")
R2_BUCKET_NAME = os.getenv("R2_BUCKET_NAME", "")
R2_ENDPOINT_URL = os.getenv("R2_ENDPOINT_URL", "")
R2_OBJECT_KEY_TEMPLATE = os.getenv(
    "R2_OBJECT_KEY_TEMPLATE", "patients/{mrn}/encounters/{encounter_id}.json"
)

# HTTP API fallback (optional)
MEASUREMENTS_API_URL_TEMPLATE = os.getenv("MEASUREMENTS_API_URL_TEMPLATE", "")
MEASUREMENTS_API_TOKEN = os.getenv("MEASUREMENTS_API_TOKEN", "")
MEASUREMENTS_API_TIMEOUT = int(os.getenv("MEASUREMENTS_API_TIMEOUT", "15"))

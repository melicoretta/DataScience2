from django.conf import settings
from django.contrib import messages
from django.contrib.auth.decorators import login_required, permission_required
from django.shortcuts import get_object_or_404, redirect, render

from patients.models import Encounter
from observations.models import ObservationSet
from .models import RiskAssessment
from .forms import GenerateRiskForm, RiskCommentForm
from .services import (
    predict_mortality_with_shap,
    predict_mortality,
    risk_band_for_probability,
)
from .driver_logic import build_clinical_drivers


@login_required
@permission_required("risk.add_riskassessment", raise_exception=True)
def generate(request, encounter_id):
    encounter = get_object_or_404(Encounter, id=encounter_id)

    latest_obs = (
        ObservationSet.objects
        .filter(encounter=encounter)
        .order_by("-id")
        .first()
    )

    if not latest_obs:
        messages.error(request, "No observations found. Enter vitals/labs first.")
        return redirect("patients:encounter_detail", encounter.id)

    if request.method == "POST":
        form = GenerateRiskForm(request.POST)
        if form.is_valid():
            # ✅ PRIMARY RISK: in-hospital
            prob_in = predict_mortality(latest_obs, model_key="mort_in")
            band_in = risk_band_for_probability(prob_in)

            # Optional: still store 180d for reference (keeps your existing field useful)
            prob_180 = predict_mortality(latest_obs, model_key="mort_180")

            ra = RiskAssessment.objects.create(
                encounter=encounter,
                observation_set=latest_obs,

                # ✅ store IN-HOSPITAL (this is what your patient list will show)
                risk_in=prob_in * 100,

                # optional: keep 180d stored too
                risk_180d=prob_180 * 100,

                # ✅ band should match in-hospital if that’s your priority
                risk_band=band_in,

                model_version=settings.ML_MODELS["mort_in"]["version"],
                created_by=request.user,
                doctor_name=form.cleaned_data.get("doctor_name", ""),
                doctor_comment="",
            )

            messages.success(request, "In-hospital risk prediction generated.")
            return redirect("risk:detail", ra.id)
    else:
        form = GenerateRiskForm()

    return render(request, "risk/generate.html", {
        "encounter": encounter,
        "form": form,
    })


@login_required
def detail(request, assessment_id):
    ra = get_object_or_404(RiskAssessment, id=assessment_id)

    # Save doctor comment (ONLY ONE comment shared across all models)
    if request.method == "POST":
        form = RiskCommentForm(request.POST)
        if form.is_valid():
            ra.doctor_comment = form.cleaned_data["doctor_comment"]
            ra.save(update_fields=["doctor_comment"])
            messages.success(request, "Doctor comment saved.")
            return redirect("risk:detail", ra.id)
    else:
        form = RiskCommentForm(initial={"doctor_comment": ra.doctor_comment})

    show_all = request.GET.get("all") == "1"

    model_panels = []
    for model_key in ["mort_in", "mort_90", "mort_180"]:  # ✅ put in-hospital first
        label = settings.ML_MODELS.get(model_key, {}).get("label", model_key)

        prob, top_shap = predict_mortality_with_shap(
            ra.observation_set,
            model_key=model_key,
            top_n=10,
        )

        drivers, shown_count, high_count, total_abnormal = build_clinical_drivers(
            ra.observation_set, show_all=show_all
        )

        model_panels.append({
            "key": model_key,
            "title": label,
            "risk_percent": prob * 100,
            "band": risk_band_for_probability(prob),
            "drivers": drivers,
            "shown_count": shown_count,
            "high_count": high_count,
            "total_abnormal": total_abnormal,
            "show_all": show_all,
            "top_shap": top_shap,
        })

    features = [(c, getattr(ra.observation_set, c)) for c in ObservationSet.feature_columns()]

    # Backward-compat variables: make the PRIMARY panel in-hospital (first)
    primary_panel = model_panels[0] if model_panels else None
    drivers = primary_panel["drivers"] if primary_panel else []
    shown_count = primary_panel["shown_count"] if primary_panel else 0
    high_count = primary_panel["high_count"] if primary_panel else 0
    total_abnormal = primary_panel["total_abnormal"] if primary_panel else 0
    top_shap = primary_panel["top_shap"] if primary_panel else []

    return render(request, "risk/detail.html", {
        "ra": ra,
        "model_panels": model_panels,
        "features": features,
        "comment_form": form,

        # backward-compat (safe if template references old vars)
        "drivers": drivers,
        "shown_count": shown_count,
        "high_count": high_count,
        "total_abnormal": total_abnormal,
        "show_all": show_all,
        "top_shap": top_shap,
    })

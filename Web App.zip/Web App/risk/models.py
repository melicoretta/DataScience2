# risk/models.py
from django.conf import settings
from django.db import models


class RiskAssessment(models.Model):
    encounter = models.ForeignKey(
        "patients.Encounter",
        on_delete=models.CASCADE,
        related_name="risk_assessments",
    )

    observation_set = models.ForeignKey(
        "observations.ObservationSet",
        on_delete=models.CASCADE,
        related_name="risk_assessments",
    )

    # ✅ In-hospital mortality (PERCENT 0..100) — this is the one you will show in patient list
    risk_in = models.FloatField()

    # Optional: keep 180d if you still want it elsewhere (not needed for patient list)
    risk_180d = models.FloatField(null=True, blank=True)

    # Consider making band correspond to IN-hospital risk (recommended)
    risk_band = models.CharField(max_length=16)

    model_version = models.CharField(max_length=64, default="")
    created_at = models.DateTimeField(auto_now_add=True)

    created_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.PROTECT,
        null=True,
        blank=True,
        related_name="risk_assessments_created",
    )

    doctor_name = models.CharField(max_length=100, blank=True, default="")
    doctor_comment = models.TextField(blank=True, default="")

    def __str__(self):
        return f"Risk #{self.id} {self.risk_band} IN:{self.risk_in:.2f}%"

from django.core.exceptions import ValidationError
from django.db import models, transaction
from django.db.models import Max
from django.utils import timezone


class Patient(models.Model):
    mrn = models.CharField("MRN", max_length=64, unique=True)
    full_name = models.CharField(max_length=255)
    date_of_birth = models.DateField(null=True, blank=True)
    sex = models.CharField(max_length=16, blank=True)

    # ✅ Recommended for real hospital behavior
    is_deceased = models.BooleanField(default=False)
    date_of_death = models.DateTimeField(null=True, blank=True)

    class Meta:
        ordering = ["full_name", "mrn"]
        indexes = [
            models.Index(fields=["mrn"]),
            models.Index(fields=["full_name"]),
        ]

    def __str__(self):
        return f"{self.full_name} ({self.mrn})"


class Encounter(models.Model):
    STATUS_ACTIVE = "ACTIVE"
    STATUS_DISCHARGED = "DISCHARGED"
    STATUS_DECEASED = "DECEASED"

    STATUS_CHOICES = [
        (STATUS_ACTIVE, "Active"),
        (STATUS_DISCHARGED, "Discharged"),
        (STATUS_DECEASED, "Deceased"),
    ]

    patient = models.ForeignKey(
        Patient,
        on_delete=models.CASCADE,
        related_name="encounters",
    )

    # Per-patient encounter sequence number (1, 2, 3, ...)
    # This is NOT the DB primary key; URLs can keep using `id`.
    encounter_number = models.PositiveIntegerField(editable=False)

    admitted_at = models.DateTimeField(default=timezone.now)

    # ✅ when the encounter ended (discharge or death)
    ended_at = models.DateTimeField(null=True, blank=True)

    unit = models.CharField(max_length=64, blank=True, help_text="e.g., ICU-A, ICU-B, Ward 3")
    bed_number = models.CharField(max_length=16, blank=True, default="")
    status = models.CharField(max_length=16, choices=STATUS_CHOICES, default=STATUS_ACTIVE)

    # --- Automation state (used by scheduled ingestion + scoring) ---
    last_ingested_signature = models.CharField(max_length=64, blank=True, default="")
    last_ingested_at = models.DateTimeField(null=True, blank=True)
    last_ingest_status = models.CharField(max_length=24, blank=True, default="")
    last_ingest_error = models.TextField(blank=True, default="")

    class Meta:
        ordering = ["-admitted_at", "-id"]
        constraints = [
            models.UniqueConstraint(
                fields=["patient", "encounter_number"],
                name="unique_encounter_number_per_patient",
            ),
        ]
        indexes = [
            models.Index(fields=["patient", "status"]),
            models.Index(fields=["status", "admitted_at"]),
        ]

    def clean(self):
        """
        ✅ Prevent more than one ACTIVE encounter per patient.
        Works on any database (even SQLite). If you use Postgres, you can also add a partial unique index.
        """
        if self.status == self.STATUS_ACTIVE and self.patient_id:
            qs = Encounter.objects.filter(patient_id=self.patient_id, status=self.STATUS_ACTIVE)
            if self.pk:
                qs = qs.exclude(pk=self.pk)
            if qs.exists():
                raise ValidationError("This patient already has an ACTIVE encounter. Discharge/close it first.")

        # ✅ Ensure ended_at is set when not active
        if self.status in (self.STATUS_DISCHARGED, self.STATUS_DECEASED) and not self.ended_at:
            # Don't force here (to avoid surprising behavior in admin/forms),
            # but you can auto-set in save() if you prefer.
            pass

        # ✅ If marked deceased encounter, patient should be deceased too (enforced in save())
        super().clean()

    def save(self, *args, **kwargs):
        """
        - Auto-assign per-patient sequential encounter_number on create (race-safe).
        - Auto-fill ended_at when status becomes DISCHARGED/DECEASED.
        - If DECEASED, also mark patient deceased.
        """
        creating = self._state.adding

        if creating and not self.encounter_number and self.patient_id:
            with transaction.atomic():
                # Lock patient row to prevent race conditions
                Patient.objects.select_for_update().filter(id=self.patient_id).values("id").first()

                max_no = (
                    Encounter.objects.filter(patient_id=self.patient_id)
                    .aggregate(m=Max("encounter_number"))
                    .get("m")
                )
                self.encounter_number = (max_no or 0) + 1

        # Run validation (enforces single ACTIVE encounter)
        self.full_clean()

        # Auto set ended_at if closing
        if self.status in (self.STATUS_DISCHARGED, self.STATUS_DECEASED) and self.ended_at is None:
            self.ended_at = timezone.now()

        # If deceased, mark patient too
        if self.status == self.STATUS_DECEASED and self.patient_id:
            # Use update() to avoid recursion & keep it simple
            now = self.ended_at or timezone.now()
            Patient.objects.filter(id=self.patient_id).update(is_deceased=True, date_of_death=now)

        return super().save(*args, **kwargs)

    def __str__(self):
        no = self.encounter_number or self.id
        return f"Encounter #{no} - {self.patient}"

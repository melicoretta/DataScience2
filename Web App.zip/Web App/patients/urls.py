# patients/urls.py
from django.urls import path
from . import views

app_name = "patients"

urlpatterns = [
    # -----------------
    # Patient
    # -----------------
    path("", views.patient_list, name="patient_list"),
    path("former/", views.former_patient_list, name="former_patient_list"),

    path("patients/new/", views.patient_create, name="patient_create"),
    path("patients/<int:patient_id>/", views.patient_detail, name="patient_detail"),
    path("patients/<int:patient_id>/delete/", views.patient_delete, name="patient_delete"),

    # -----------------
    # Encounter
    # -----------------
    path("encounters/new/", views.encounter_create, name="encounter_create"),
    path("encounters/<int:encounter_id>/", views.encounter_detail, name="encounter_detail"),

    # clinical actions (NOT delete)
    path(
        "encounters/<int:encounter_id>/discharge/",
        views.encounter_discharge,
        name="encounter_discharge",
    ),
    path(
        "encounters/<int:encounter_id>/deceased/",
        views.encounter_mark_deceased,
        name="encounter_mark_deceased",
    ),

    # hard delete
    path(
        "encounters/<int:pk>/delete/",
        views.encounter_delete,
        name="encounter_delete",
    ),
]

from django import forms
from django.db.models import Q
from .models import Patient, Encounter


class PatientForm(forms.ModelForm):
    class Meta:
        model = Patient
        fields = ["mrn", "full_name", "date_of_birth", "sex"]
        widgets = {
            "date_of_birth": forms.DateInput(attrs={"type": "date"}),
        }


class EncounterForm(forms.ModelForm):
    class Meta:
        model = Encounter
        fields = ["patient", "admitted_at", "unit", "bed_number", "status"]
        widgets = {
            "admitted_at": forms.DateTimeInput(attrs={"type": "datetime-local"}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        # ✅ show ALL patients (active + former + new)
        self.fields["patient"].queryset = Patient.objects.all().order_by("full_name", "mrn")
